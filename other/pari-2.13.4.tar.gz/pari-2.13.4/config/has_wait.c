#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
main(){ wait(NULL); }
