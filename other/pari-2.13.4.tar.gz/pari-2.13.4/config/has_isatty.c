#include <unistd.h>
int main(){ isatty(0); return 0; }
